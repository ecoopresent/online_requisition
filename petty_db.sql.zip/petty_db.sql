-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2021 at 03:20 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petty_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE `audit_trail` (
  `id` int(10) UNSIGNED NOT NULL,
  `audit_action` varchar(255) NOT NULL,
  `audit_date` date NOT NULL,
  `audit_user` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `canvas`
--

CREATE TABLE `canvas` (
  `id` int(10) UNSIGNED NOT NULL,
  `pr_id` int(10) UNSIGNED NOT NULL,
  `supplier1` varchar(105) NOT NULL,
  `supplier2` varchar(105) NOT NULL,
  `supplier3` varchar(105) NOT NULL,
  `supplier4` varchar(105) NOT NULL,
  `supplier5` varchar(105) NOT NULL,
  `remarks` varchar(1000) NOT NULL,
  `approved_by` varchar(45) NOT NULL,
  `canvas_date` date NOT NULL,
  `canvas_status` varchar(45) NOT NULL,
  `date_approved` date NOT NULL,
  `operation_incharge` varchar(255) NOT NULL,
  `oi_date_approved` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `canvas_attachments`
--

CREATE TABLE `canvas_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `preq_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `attachment` varchar(205) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `canvas_details`
--

CREATE TABLE `canvas_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `canvas_id` int(10) UNSIGNED NOT NULL,
  `qty` int(10) UNSIGNED NOT NULL,
  `uom` varchar(45) NOT NULL,
  `product_desc` varchar(405) NOT NULL,
  `price1` varchar(45) NOT NULL,
  `price2` varchar(45) NOT NULL,
  `price3` varchar(45) NOT NULL,
  `price4` varchar(45) NOT NULL,
  `price5` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cashcheck`
--

CREATE TABLE `cashcheck` (
  `id` int(10) UNSIGNED NOT NULL,
  `pr_id` int(10) UNSIGNED NOT NULL,
  `department` varchar(45) NOT NULL,
  `payee` varchar(45) NOT NULL,
  `date_prepared` date NOT NULL,
  `date_needed` date NOT NULL,
  `particulars` varchar(1000) NOT NULL,
  `amount` varchar(45) NOT NULL,
  `purpose` varchar(1000) NOT NULL,
  `remarks` varchar(1000) NOT NULL,
  `charge_to` varchar(45) NOT NULL,
  `budget` varchar(45) NOT NULL,
  `liquidated_on` date NOT NULL,
  `prepared_by` varchar(45) NOT NULL,
  `department_head` varchar(45) NOT NULL,
  `president` varchar(45) NOT NULL,
  `accounting` varchar(45) NOT NULL,
  `cash_status` varchar(45) NOT NULL,
  `date_preapproved` date NOT NULL,
  `date_approved` date NOT NULL,
  `approver_type` varchar(50) NOT NULL,
  `head_approver` text NOT NULL,
  `date_headapproved` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(10) UNSIGNED NOT NULL,
  `department` varchar(45) NOT NULL,
  `department_head` varchar(105) NOT NULL,
  `department_email` varchar(105) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department`, `department_head`, `department_email`) VALUES
(8, 'IT', 'Neil De Guzman', 'jericopresentacion08@gmail.com'),
(9, 'Admin', 'Susan T. Panugayan', 'jericopresentacion08@gmail.com'),
(10, 'Purchasing', 'Susan T. Panugayan', 'jericopresentacion08@gmail.com'),
(11, 'Accounting', 'Jossie Bataller', 'jericopresentacion08@gmail.com'),
(12, 'Finance', 'Mylene Pazcoguin', 'jericopresentacion08@gmail.com'),
(13, 'HR', 'Marjorie Cortiguerra', 'jericopresentacion08@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `liquidation`
--

CREATE TABLE `liquidation` (
  `id` int(10) UNSIGNED NOT NULL,
  `pettycash_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(45) NOT NULL,
  `liquidation_date` date NOT NULL,
  `branch` varchar(45) NOT NULL,
  `position` varchar(45) NOT NULL,
  `prepared_by` varchar(45) NOT NULL,
  `checked_by` varchar(45) NOT NULL,
  `approved_by` varchar(45) NOT NULL,
  `particulars` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `liquidation_details`
--

CREATE TABLE `liquidation_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `liquidation_id` int(10) UNSIGNED NOT NULL,
  `l_from` varchar(455) NOT NULL,
  `l_to` varchar(455) NOT NULL,
  `vehicle_type` varchar(455) NOT NULL,
  `amount` varchar(455) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payee`
--

CREATE TABLE `payee` (
  `id` int(10) UNSIGNED NOT NULL,
  `payee_name` varchar(45) NOT NULL,
  `payee_email` varchar(45) NOT NULL,
  `payee_dept` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pettycash`
--

CREATE TABLE `pettycash` (
  `id` int(10) UNSIGNED NOT NULL,
  `department` varchar(45) NOT NULL,
  `voucher_date` date NOT NULL,
  `voucher_no` varchar(45) NOT NULL,
  `particulars` text NOT NULL,
  `cash_advance` varchar(45) NOT NULL,
  `actual_amount` varchar(45) NOT NULL,
  `charge_to` varchar(45) NOT NULL,
  `liquidated_on` date NOT NULL,
  `requested_by` varchar(45) NOT NULL,
  `approved_by` varchar(45) NOT NULL,
  `authorized` varchar(45) NOT NULL,
  `pettycash_status` varchar(45) NOT NULL,
  `liquidation` varchar(45) NOT NULL,
  `remarks` text NOT NULL,
  `payee_id` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pr`
--

CREATE TABLE `pr` (
  `id` int(10) UNSIGNED NOT NULL,
  `department` varchar(45) NOT NULL,
  `date_prepared` date NOT NULL,
  `date_needed` date NOT NULL,
  `pr_no` varchar(45) NOT NULL,
  `purpose` varchar(1000) NOT NULL,
  `requested_by` varchar(45) NOT NULL,
  `approved_by` varchar(45) NOT NULL,
  `pr_status` varchar(45) NOT NULL,
  `remarks` varchar(1000) NOT NULL,
  `date_approve` date NOT NULL,
  `pr_type` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pr_details`
--

CREATE TABLE `pr_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `pr_id` int(10) UNSIGNED NOT NULL,
  `item_code` varchar(45) NOT NULL,
  `stock` int(10) UNSIGNED NOT NULL,
  `rqmt` int(10) UNSIGNED NOT NULL,
  `uom` varchar(45) NOT NULL,
  `item_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rca_attachments`
--

CREATE TABLE `rca_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `cashcheck_id` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `attachment` varchar(205) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `user_status` varchar(45) NOT NULL,
  `user_type` varchar(45) NOT NULL,
  `user_dept` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`id`, `full_name`, `username`, `password`, `user_status`, `user_type`, `user_dept`) VALUES
(9, 'Administrator', 'admin', 'admin', 'active', 'Administrator', 'Admin'),
(15, 'Michelle E Belches', 'purchaser', 'purchaser', 'active', 'Purchaser', 'Purchasing'),
(16, 'IT Dept.', 'itdept', 'itdept', 'active', 'Enduser', 'IT'),
(18, 'Accounting', 'accounting', 'acct@pmc', 'active', 'Accounting', 'Accounting');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_trail`
--
ALTER TABLE `audit_trail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `canvas`
--
ALTER TABLE `canvas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `canvas_attachments`
--
ALTER TABLE `canvas_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `canvas_details`
--
ALTER TABLE `canvas_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashcheck`
--
ALTER TABLE `cashcheck`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liquidation`
--
ALTER TABLE `liquidation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liquidation_details`
--
ALTER TABLE `liquidation_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payee`
--
ALTER TABLE `payee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pettycash`
--
ALTER TABLE `pettycash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pr`
--
ALTER TABLE `pr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pr_details`
--
ALTER TABLE `pr_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rca_attachments`
--
ALTER TABLE `rca_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_trail`
--
ALTER TABLE `audit_trail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `canvas`
--
ALTER TABLE `canvas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `canvas_attachments`
--
ALTER TABLE `canvas_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `canvas_details`
--
ALTER TABLE `canvas_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cashcheck`
--
ALTER TABLE `cashcheck`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `liquidation`
--
ALTER TABLE `liquidation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `liquidation_details`
--
ALTER TABLE `liquidation_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payee`
--
ALTER TABLE `payee`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pettycash`
--
ALTER TABLE `pettycash`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pr`
--
ALTER TABLE `pr`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pr_details`
--
ALTER TABLE `pr_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rca_attachments`
--
ALTER TABLE `rca_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
